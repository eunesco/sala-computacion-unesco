create table if not exists public.activity_plans (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  profesor text not null,
  rol_usuario text not null default 'docente',
  curso text not null,
  asignatura text not null,
  oa text not null,
  tipo_actividad text not null,
  duracion text not null,
  nombre_actividad text not null,
  dificultad text,
  planificacion jsonb not null,
  rating integer check (rating between 1 and 5),
  comentario_valoracion text,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

alter table public.activity_plans
add column if not exists generation_source text not null default 'plantilla_base';

alter table public.activity_plans
add column if not exists template_example_count integer not null default 0;

alter table public.activity_plans
add column if not exists template_quality text;

alter table public.activity_plans
add column if not exists approved_as_template boolean not null default false;

alter table public.activity_plans
add column if not exists template_approved_at timestamp with time zone;

create table if not exists public.activity_plan_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  activity_plan_id uuid not null references public.activity_plans(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comentario text,
  fecha timestamp with time zone not null default now()
);

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_activity_plans_updated_at on public.activity_plans;
create trigger set_activity_plans_updated_at
before update on public.activity_plans
for each row
execute function public.set_updated_at();

alter table public.activity_plans enable row level security;
alter table public.activity_plan_feedback enable row level security;

drop policy if exists "Leer planificaciones de actividades" on public.activity_plans;
create policy "Leer planificaciones de actividades"
on public.activity_plans
for select
to anon
using (true);

drop policy if exists "Crear planificaciones de actividades" on public.activity_plans;
create policy "Crear planificaciones de actividades"
on public.activity_plans
for insert
to anon
with check (true);

drop policy if exists "Actualizar planificaciones de actividades" on public.activity_plans;
create policy "Actualizar planificaciones de actividades"
on public.activity_plans
for update
to anon
using (true)
with check (true);

drop policy if exists "Leer valoraciones de actividades" on public.activity_plan_feedback;
create policy "Leer valoraciones de actividades"
on public.activity_plan_feedback
for select
to anon
using (true);

drop policy if exists "Crear valoraciones de actividades" on public.activity_plan_feedback;
create policy "Crear valoraciones de actividades"
on public.activity_plan_feedback
for insert
to anon
with check (true);
