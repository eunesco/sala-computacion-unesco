-- Modulo Informe de Notas - Escuela Unesco
-- Ejecutar en Supabase SQL Editor.

create table if not exists public.gradebook_students (
  id uuid primary key default gen_random_uuid(),
  curso text not null,
  nombres text not null,
  apellido_paterno text not null,
  apellido_materno text default '',
  run text default '',
  estado text not null default 'activo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.gradebook_entries (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.gradebook_students(id) on delete cascade,
  profesor text not null,
  curso text not null,
  asignatura text not null,
  notas jsonb not null default '[]'::jsonb,
  promedio integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists gradebook_entries_unique_planilla
on public.gradebook_entries (student_id, profesor, curso, asignatura);

create table if not exists public.gradebook_attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.gradebook_students(id) on delete cascade,
  curso text not null,
  asistencia integer check (asistencia between 0 and 100),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists gradebook_attendance_unique_student_course
on public.gradebook_attendance (student_id, curso);

alter table public.gradebook_students enable row level security;
alter table public.gradebook_entries enable row level security;
alter table public.gradebook_attendance enable row level security;

drop policy if exists "gradebook_students_read" on public.gradebook_students;
drop policy if exists "gradebook_students_write" on public.gradebook_students;
drop policy if exists "gradebook_entries_read" on public.gradebook_entries;
drop policy if exists "gradebook_entries_write" on public.gradebook_entries;
drop policy if exists "gradebook_attendance_read" on public.gradebook_attendance;
drop policy if exists "gradebook_attendance_write" on public.gradebook_attendance;

create policy "gradebook_students_read"
on public.gradebook_students for select
using (true);

create policy "gradebook_students_write"
on public.gradebook_students for all
using (true)
with check (true);

create policy "gradebook_entries_read"
on public.gradebook_entries for select
using (true);

create policy "gradebook_entries_write"
on public.gradebook_entries for all
using (true)
with check (true);

create policy "gradebook_attendance_read"
on public.gradebook_attendance for select
using (true);

create policy "gradebook_attendance_write"
on public.gradebook_attendance for all
using (true)
with check (true);

-- Ejemplo de carga de estudiantes:
-- insert into public.gradebook_students (curso, apellido_paterno, apellido_materno, nombres, run)
-- values ('5° Básico', 'Pérez', 'González', 'Ana María', '12.345.678-9');
